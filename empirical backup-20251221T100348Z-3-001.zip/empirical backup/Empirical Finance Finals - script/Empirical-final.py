#!/usr/bin/env python3
# empirical_analysis.py

import pandas as pd
import numpy as np
import statsmodels.api as sm
from scipy.stats import skew, kurtosis

def load_price_data(filename):
    """
    Load the CSV of daily prices, parse the 'Name' column as a date
    with dayfirst=True so that '1/1/2021' → 2021-01-01, etc.
    Return a DataFrame indexed by Date, sorted ascending.
    """
    df = pd.read_csv(filename, parse_dates=['Name'], dayfirst=True)
    df.rename(columns={'Name': 'Date'}, inplace=True)
    df.set_index('Date', inplace=True)
    df.sort_index(inplace=True)
    return df

def compute_daily_returns(df_price):
    """
    Compute simple daily returns: (P_t - P_{t-1}) / P_{t-1}.
    """
    df_ret = df_price.pct_change().dropna(how='all')
    return df_ret

def descriptive_statistics(df_ret, out_csv='descriptive_stats.csv'):
    """
    Compute summary stats on the daily returns:
      • Mean, StdDev, Min, Max, Skewness, ExcessKurtosis, Autocorr(1), Observations
    Save to CSV and print to console.
    """
    summary = {
        'Ticker': [],
        'Mean': [],
        'StdDev': [],
        'Min': [],
        'Max': [],
        'Skewness': [],
        'ExcessKurtosis': [],
        'Autocorr(1)': [],
        'Observations': []
    }
    for col in df_ret.columns:
        r = df_ret[col].dropna()
        summary['Ticker'].append(col)
        summary['Mean'].append(r.mean())
        summary['StdDev'].append(r.std(ddof=1))
        summary['Min'].append(r.min())
        summary['Max'].append(r.max())
        summary['Skewness'].append(skew(r, bias=False))
        summary['ExcessKurtosis'].append(kurtosis(r, fisher=True, bias=False))
        summary['Autocorr(1)'].append(r.autocorr(lag=1))
        summary['Observations'].append(r.shape[0])
    df_summary = pd.DataFrame(summary).set_index('Ticker')
    df_summary.to_csv(out_csv)
    print(f"\nDescriptive statistics (daily) saved to '{out_csv}':\n")
    print(df_summary, "\n")
    return df_summary

def load_ff_daily(filename):
    """
    Load the daily Fama–French CSV, skip first 3 rows, parse 'Date' as YYYYMMDD,
    convert factor columns from percentages to decimals, return DataFrame indexed by Date.
    """
    df_ff = pd.read_csv(filename, skiprows=3).dropna()
    if 'Unnamed: 0' in df_ff.columns:
        df_ff.rename(columns={'Unnamed: 0': 'Date'}, inplace=True)
    # Parse date (YYYYMMDD)
    df_ff['Date'] = pd.to_datetime(df_ff['Date'], format='%Y%m%d')
    df_ff.set_index('Date', inplace=True)
    # Convert percent columns to decimal
    for col in ['Mkt-RF', 'SMB', 'HML', 'RF']:
        if col in df_ff.columns:
            df_ff[col] = df_ff[col] / 100.0
    return df_ff

def estimate_factor_loadings_daily(df_ret, df_ff, out_csv='factor_loadings.csv'):
    """
    Merge daily returns (df_ret) with daily FF factors (df_ff) via df_ret.join(df_ff).
    Then run OLS for each ticker:
      R_{i,t} - RF_t = α_i + β_i,m (Mkt-RF)_t + β_i,SMB SMB_t + β_i,HML HML_t + ε_{i,t}
    Save alphas, betas, R2 to CSV.
    """
    # Inner join on the Date index → only keep dates present in both
    df_all = df_ret.join(df_ff, how='inner')
    results = []
    for col in df_ret.columns:
        y = df_all[col] - df_all['RF']       # daily excess return
        X = df_all[['Mkt-RF', 'SMB', 'HML']] # daily factor returns
        X = sm.add_constant(X)
        # If there are no overlapping dates for this col, skip
        if y.isna().all():
            print(f"Warning: No overlap for ticker {col}. Skipping regression.")
            continue
        model = sm.OLS(y.dropna(), X.loc[y.dropna().index], missing='drop').fit()
        results.append({
            'Ticker'   : col,
            'Alpha'    : model.params.get('const', np.nan),
            'Beta_Mkt' : model.params.get('Mkt-RF', np.nan),
            'Beta_SMB' : model.params.get('SMB', np.nan),
            'Beta_HML' : model.params.get('HML', np.nan),
            'R2'       : model.rsquared
        })
    df_betas = pd.DataFrame(results).set_index('Ticker')
    df_betas.to_csv(out_csv)
    print(f"\nDaily factor loadings saved to '{out_csv}':\n")
    print(df_betas, "\n")
    return df_betas, df_all

def cross_sectional_regression(df_betas, df_all):
    """
    Run a cross‐sectional regression of average excess return on estimated betas.
    Ensures we compute the mean across rows (axis=0) to get one value per ticker.
    """
    # 1) Construct excess returns DataFrame: (R_i,t - RF_t)
    excess_df = df_all[df_betas.index].sub(df_all['RF'], axis=0)

    # 2) Take the average across dates (axis=0) to get one number per ticker
    avg_excess = excess_df.mean(axis=0)  # Series of length = number of tickers

    # 3) Map those average excess returns back into df_betas
    df_betas['Avg_Excess_Return'] = df_betas.index.map(avg_excess)

    # 4) Run cross‐sectional OLS: Avg_Excess_Return ~ 1 + Beta_Mkt + Beta_SMB + Beta_HML
    X_cs = df_betas[['Beta_Mkt', 'Beta_SMB', 'Beta_HML']]
    X_cs = sm.add_constant(X_cs)
    y_cs = df_betas['Avg_Excess_Return']

    cs_model = sm.OLS(y_cs, X_cs).fit()
    print("Cross‐sectional regression of Avg Excess Return on betas:\n")
    print(cs_model.summary(), "\n")


def anomaly_checks_daily(df_price, df_ret, df_all, out_csv='anomaly_checks.csv'):
    """
    Compute two simple daily anomalies:
      1) 1-day reversal: corr(r_{i,t-1}, r_{i,t})
      2) 21-day momentum: corr(cumreturn over days t-21 to t-1, r_{i,t})
    Save to CSV.
    """
    rev_stats = []
    for col in df_ret.columns:
        rev_corr = df_ret[col].autocorr(lag=1)
        rev_stats.append((col, rev_corr))
    df_rev = pd.DataFrame(rev_stats, columns=['Ticker', 'Reversal_Corr']).set_index('Ticker')

    mom_stats = []
    lag = 21
    cumret = (1 + df_price.pct_change()).rolling(window=lag).apply(np.prod, raw=True).shift(1) - 1
    for col in df_price.columns:
        signal = cumret[col].reindex(df_ret.index)
        ret_next = df_ret[col]
        mom_corr = signal.corr(ret_next)
        mom_stats.append((col, mom_corr))
    df_mom = pd.DataFrame(mom_stats, columns=['Ticker', 'Mom21_Corr']).set_index('Ticker')

    df_anom = df_rev.join(df_mom, how='inner')
    df_anom.to_csv(out_csv)
    print(f"\nDaily anomaly checks saved to '{out_csv}':\n")
    print(df_anom, "\n")
    return df_anom


def main():
    # 1) Load daily price data
    price_filename = 'data_2025t2.csv'
    print(f"Loading daily price data from '{price_filename}'...")
    df_price = load_price_data(price_filename)

    # 2) Compute daily returns
    print("Computing daily returns...")
    df_ret = compute_daily_returns(df_price)

    # 3) Descriptive stats (Part 4a)
    print("Generating descriptive statistics (Part 4a)...")
    descriptive_statistics(df_ret, out_csv='descriptive_stats.csv')

    # 4) Load daily Fama–French factors (Part 4b)
    ff_filename = 'F-F_Research_Data_Factors_daily.csv'
    print(f"\nLoading daily Fama–French factors from '{ff_filename}'...")
    df_ff = load_ff_daily(ff_filename)

    # 5) Estimate daily factor loadings (Part 4b)
    print("Estimating daily factor loadings (Part 4b)...")
    df_betas, df_all = estimate_factor_loadings_daily(df_ret, df_ff, out_csv='factor_loadings.csv')

    # 6) Cross‐sectional regression (Part 4b)
    print("Running cross‐sectional regression (Part 4b)...")
    cross_sectional_regression(df_betas, df_all)

    # 7) Daily anomaly checks (Part 4c)
    print("Performing daily anomaly checks (Part 4c)...")
    anomaly_checks_daily(df_price, df_ret, df_all, out_csv='anomaly_checks.csv')


if __name__ == '__main__':
    main()
